# Capture2Text
This project is forked from http://capture2text.sourceforge.net/

## Getting Started

### Windows
1. Download CMake, Qt5(with msvc2010), Visual Studio 2017(with C++ Desktop Development workload) and CCPAN.

2. Make sure the following environments are properly confingured.


| NAME              | VALUE                                                      |
| :---------------: | ---------------------------------------------------------- |
| CMAKE_PREFIX_PATH | C:\Qt\Qt5.9.2\5.9.2\msvc2017_64\lib\cmake\Qt5Network;      |
|                   | C:\Qt\Qt5.9.2\5.9.2\msvc2017_64\lib\cmake\Qt5TextToSpeech; |
|                   | C:\Qt\Qt5.9.2\5.9.2\msvc2017_64\lib\cmake\Qt5Widgets;      |
| PATH              | C:\Program Files\CPPAN;                                    |
|                   | C:\Program Files\CMake\bin;                                |
|                   | C:\Qt\Qt5.9.2\5.9.2\msvc2017_64\bin;                       |
|                   | C:\Qt\Qt5.9.2\Tools\QtCreator\bin;                         |

3. Open a new console in the root folder of the project:
```
> cppan  # This must be done if you have never run cppan on this machine.
> MD build
> CD build\
> cmake .. -G "Visual Studio 15 2017 Win64"
```

4. Open the Capture2Text.sln in the build folder, build dependencies. 
   Then choose Capture2Text as Startup Target. Build.

5. Copy the folder traindata/* into the Debug/Release folder. Run.
